# Dropout Tracker (frontend)
`npm install && npm run dev`
Structure: `src/pages` (7 pages), `src/components` (Layout, ui kit), `src/context/DataContext.jsx` (single data layer — replace its local state/setters with API calls), `src/data/mock.js` (dummy data).

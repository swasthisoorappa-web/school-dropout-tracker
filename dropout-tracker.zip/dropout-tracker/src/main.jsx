import React from 'react';import {createRoot} from 'react-dom/client';import {BrowserRouter} from 'react-router-dom';
import {DataProvider} from './context/DataContext';import App from './App';import './index.css';
createRoot(document.getElementById('root')).render(<BrowserRouter><DataProvider><App/></DataProvider></BrowserRouter>);

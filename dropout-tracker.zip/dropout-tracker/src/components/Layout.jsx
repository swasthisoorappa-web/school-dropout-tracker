import {useState} from 'react';import {NavLink,Outlet,useNavigate} from 'react-router-dom';
import {LayoutDashboard,Users,CalendarCheck,BarChart3,AlertTriangle,PhoneCall,FileText,Menu,Search,Bell,GraduationCap} from 'lucide-react';
const nav=[['/','Dashboard',LayoutDashboard],['/students','Students',Users],['/attendance','Attendance',CalendarCheck],['/analytics','Analytics',BarChart3],['/at-risk','At-Risk Students',AlertTriangle],['/follow-ups','Follow-ups',PhoneCall],['/reports','Reports',FileText]];
export default function Layout(){const [open,setOpen]=useState(false);const go=useNavigate();
 return(<div className="min-h-screen text-slate-700">
 {open&&<div className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden" onClick={()=>setOpen(false)}/>}
 <aside className={`fixed inset-y-0 left-0 z-40 w-64 border-r border-slate-200 bg-white transition-transform print:hidden ${open?'translate-x-0':'-translate-x-full'} lg:translate-x-0`}>
  <div className="flex items-center gap-2 px-5 py-5 text-lg font-bold text-blue-700"><GraduationCap/>DropoutTracker</div>
  <nav className="space-y-1 px-3">{nav.map(([to,l,I])=><NavLink key={to} to={to} end={to==='/'} onClick={()=>setOpen(false)} className={({isActive})=>`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium ${isActive?'bg-blue-600 text-white':'text-slate-600 hover:bg-blue-50'}`}><I size={18}/>{l}</NavLink>)}</nav>
 </aside>
 <div className="lg:pl-64">
  <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white px-4 py-3 print:hidden">
   <button className="lg:hidden" onClick={()=>setOpen(true)}><Menu/></button>
   <form className="relative max-w-md flex-1" onSubmit={e=>{e.preventDefault();go('/students?q='+encodeURIComponent(e.target.q.value))}}><Search size={16} className="absolute left-3 top-3 text-slate-400"/><input name="q" placeholder="Search students..." className="w-full rounded-lg bg-slate-100 py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-blue-200"/></form>
   <div className="ml-auto flex items-center gap-4"><Bell size={20}/><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white">A</div><span className="hidden text-sm font-medium sm:block">Admin</span></div></div>
  </header>
  <main className="p-4 sm:p-6"><Outlet/></main></div></div>)}

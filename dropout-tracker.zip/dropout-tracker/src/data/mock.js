// Dummy data. Replace with API responses later (see context/DataContext.jsx).
export const CLASSES=['6-A','6-B','7-A','7-B','8-A','8-B','9-A','9-B','10-A'];
const names=['Aarav Shetty','Diya Rao','Rohan Naik','Ananya Pai','Karthik Bhat','Meera Kamath','Vihaan Shenoy','Sanvi Hegde','Arjun Poojary','Ishita Kini','Nikhil Acharya','Pooja Salian','Suresh Gowda','Divya Shetty','Manoj Kumar','Riya Fernandes','Harsh Nayak','Kavya Rai','Pranav Prabhu','Sneha D\'Souza','Yash Moily','Tanvi Bangera','Deepak Gatty','Nandini Kotian','Rahul Devadiga','Shreya Mallya','Varun Suvarna','Aditi Hebbar','Mohan Shetty','Lavanya Naik','Chetan Poojary','Bhavya Rao','Sagar Amin','Rekha Kulal','Tejas Shenoy','Sahana Pai'];
const rnd=i=>((i*9301+49297)%233280)/233280;
export const students=names.map((name,i)=>{const absent=Math.round(rnd(i+3)*(i%4===0?24:8));
 return{id:'S'+(1001+i),name,cls:CLASSES[i%9],roll:Math.floor(i/9)+1,gender:i%2?'Female':'Male',guardian:'Parent of '+name.split(' ')[0],
 phone:'98450'+String(10000+i*377).slice(0,5),address:'Benjanapadavu, Karnataka',absent,total:60,streak:i%4===0?Math.min(6,Math.round(rnd(i)*7)):Math.round(rnd(i)*2),absentToday:i%7===0}});
export const pct=s=>Math.round((s.total-s.absent)/s.total*100);
export const riskOf=s=>{const p=pct(s);return p<75||s.streak>=5?'High':p<85||s.streak>=3?'Medium':'Low'};
export const reasonsOf=s=>[pct(s)<85&&`Attendance ${pct(s)}% (below 85%)`,s.streak>=3&&`${s.streak} consecutive absences`,s.absent>=10&&`${s.absent} absences in last 60 days`].filter(Boolean);
export const classStats=list=>CLASSES.map(c=>{const ss=list.filter(s=>s.cls===c);const p=ss.length?Math.round(ss.reduce((a,s)=>a+pct(s),0)/ss.length):0;return{cls:c,students:ss.length,attendance:p,absent:ss.filter(s=>s.absentToday).length,atRisk:ss.filter(s=>riskOf(s)!=='Low').length}});
export const weekly=[{d:'Mon',v:93},{d:'Tue',v:91},{d:'Wed',v:89},{d:'Thu',v:90},{d:'Fri',v:85},{d:'Sat',v:82}];
export const monthly=[{m:'Jun',v:92},{m:'Jul',v:90},{m:'Aug',v:88},{m:'Sep',v:89},{m:'Oct',v:86},{m:'Nov',v:88}];
export const absTrend=[{w:'W1',n:14},{w:'W2',n:18},{w:'W3',n:16},{w:'W4',n:22},{w:'W5',n:19},{w:'W6',n:27},{w:'W7',n:24},{w:'W8',n:21}];
export const followups=[
{id:'F1',studentId:'S1001',contact:'Phone call',reason:'Illness',notes:'Parent said child had fever; to return next week.',date:'2026-11-24',status:'In Progress'},
{id:'F2',studentId:'S1005',contact:'Home visit',reason:'Family migration',notes:'Needs counsellor visit.',date:'2026-11-26',status:'Pending'},
{id:'F3',studentId:'S1009',contact:'SMS',reason:'Financial issues',notes:'Scholarship info shared.',date:'2026-11-20',status:'Resolved'}];
export const activity=[{text:'Attendance saved for class 8-A',time:'10 min ago'},{text:'Follow-up resolved for Ishita Kini',time:'1 hr ago'},{text:'Aarav Shetty flagged as high risk',time:'2 hrs ago'},{text:'New student Sagar Amin added',time:'Yesterday'}];

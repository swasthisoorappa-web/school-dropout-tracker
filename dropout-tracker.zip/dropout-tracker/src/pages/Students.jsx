import {useState} from 'react';import {useSearchParams} from 'react-router-dom';import {Plus,Search} from 'lucide-react';
import {useData} from '../context/DataContext';import {CLASSES,pct,riskOf,reasonsOf} from '../data/mock';import {Card,PageHeader,Btn,Modal,Field,Table,Badge,inp} from '../components/ui';
const blank={name:'',cls:CLASSES[0],roll:'',gender:'Male',guardian:'',phone:'',address:''};
export default function Students(){const {students,followups,addStudent}=useData();const [sp]=useSearchParams();
 const [q,setQ]=useState(sp.get('q')||'');const [cls,setCls]=useState('');const [risk,setRisk]=useState('');const [add,setAdd]=useState(false);const [f,setF]=useState(blank);const [sel,setSel]=useState(null);
 const list=students.filter(s=>(s.name+s.id).toLowerCase().includes(q.toLowerCase())&&(!cls||s.cls===cls)&&(!risk||riskOf(s)===risk));
 const set=k=>e=>setF({...f,[k]:e.target.value});
 return(<><PageHeader title="Student Management" subtitle={`${list.length} students`}><Btn onClick={()=>setAdd(true)}><Plus size={16}/>Add Student</Btn></PageHeader>
 <Card><div className="mb-4 flex flex-wrap gap-3"><div className="relative min-w-52 flex-1"><Search size={16} className="absolute left-3 top-3 text-slate-400"/><input className={inp+' pl-9'} placeholder="Search name or ID" value={q} onChange={e=>setQ(e.target.value)}/></div>
  <select className={inp+' !w-36'} value={cls} onChange={e=>setCls(e.target.value)}><option value="">All classes</option>{CLASSES.map(c=><option key={c}>{c}</option>)}</select>
  <select className={inp+' !w-36'} value={risk} onChange={e=>setRisk(e.target.value)}><option value="">All risk</option>{['High','Medium','Low'].map(c=><option key={c}>{c}</option>)}</select></div>
 <Table cols={['ID','Name','Class','Guardian','Attendance','Risk']}>{list.map(s=><tr key={s.id} className="cursor-pointer hover:bg-blue-50/50" onClick={()=>setSel(s)}><td className="px-3 py-2.5">{s.id}</td><td className="px-3 font-medium">{s.name}</td><td className="px-3">{s.cls}</td><td className="px-3">{s.guardian}</td><td className="px-3">{pct(s)}%</td><td className="px-3"><Badge>{riskOf(s)}</Badge></td></tr>)}</Table>
 {!list.length&&<p className="py-8 text-center text-slate-400">No students found</p>}</Card>
 <Modal open={add} onClose={()=>setAdd(false)} title="Add Student"><form className="space-y-3" onSubmit={e=>{e.preventDefault();addStudent({...f,roll:+f.roll});setF(blank);setAdd(false)}}>
  <Field label="Full name"><input required className={inp} value={f.name} onChange={set('name')}/></Field>
  <div className="grid grid-cols-3 gap-3"><Field label="Class"><select className={inp} value={f.cls} onChange={set('cls')}>{CLASSES.map(c=><option key={c}>{c}</option>)}</select></Field><Field label="Roll no."><input required type="number" className={inp} value={f.roll} onChange={set('roll')}/></Field><Field label="Gender"><select className={inp} value={f.gender} onChange={set('gender')}><option>Male</option><option>Female</option></select></Field></div>
  <Field label="Guardian name"><input required className={inp} value={f.guardian} onChange={set('guardian')}/></Field><Field label="Phone"><input required pattern="[0-9]{10}" title="10 digits" className={inp} value={f.phone} onChange={set('phone')}/></Field><Field label="Address"><input className={inp} value={f.address} onChange={set('address')}/></Field>
  <Btn className="w-full">Save Student</Btn></form></Modal>
 <Modal open={!!sel} onClose={()=>setSel(null)} title="Student Profile">{sel&&<div className="space-y-3 text-sm">
  <div className="flex items-center gap-3"><div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-lg font-bold text-white">{sel.name[0]}</div><div><p className="font-semibold">{sel.name}</p><p className="text-slate-500">{sel.id} · Class {sel.cls} · Roll {sel.roll}</p></div><span className="ml-auto"><Badge>{riskOf(sel)}</Badge></span></div>
  <div className="grid grid-cols-2 gap-2 rounded-lg bg-slate-50 p-3"><p>Attendance: <b>{pct(sel)}%</b></p><p>Absent days: <b>{sel.absent}</b></p><p>Guardian: <b>{sel.guardian}</b></p><p>Phone: <b>{sel.phone}</b></p><p className="col-span-2">Address: <b>{sel.address}</b></p></div>
  <div><p className="font-medium">Risk reasons</p>{reasonsOf(sel).length?<ul className="list-disc pl-5">{reasonsOf(sel).map(r=><li key={r}>{r}</li>)}</ul>:<p className="text-slate-500">None</p>}</div>
  <div><p className="font-medium">Follow-ups</p>{followups.filter(x=>x.studentId===sel.id).map(x=><p key={x.id}>{x.date} · {x.reason} · <Badge>{x.status}</Badge></p>)}</div></div>}</Modal></>)}

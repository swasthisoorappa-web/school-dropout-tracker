import {useState,useEffect} from 'react';import {Check,X} from 'lucide-react';
import {useData} from '../context/DataContext';import {CLASSES} from '../data/mock';import {Card,PageHeader,Btn,Table,inp} from '../components/ui';
export default function Attendance(){const {students,saveAttendance}=useData();const [cls,setCls]=useState(CLASSES[0]);const [date,setDate]=useState(new Date().toISOString().slice(0,10));
 const list=students.filter(s=>s.cls===cls);const [abs,setAbs]=useState([]);const [saved,setSaved]=useState(false);
 useEffect(()=>{setAbs(list.filter(s=>s.absentToday).map(s=>s.id));setSaved(false)},[cls,date]);
 const mark=(id,a)=>{setSaved(false);setAbs(p=>a?[...new Set([...p,id])]:p.filter(x=>x!==id))};
 return(<><PageHeader title="Attendance" subtitle="Mark daily class attendance"><Btn variant="ghost" onClick={()=>{setAbs([]);setSaved(false)}}>Mark All Present</Btn><Btn onClick={()=>{saveAttendance(cls,abs);setSaved(true)}}>Save Attendance</Btn></PageHeader>
 <Card><div className="mb-4 flex flex-wrap items-center gap-3"><select className={inp+' !w-32'} value={cls} onChange={e=>setCls(e.target.value)}>{CLASSES.map(c=><option key={c}>{c}</option>)}</select><input type="date" className={inp+' !w-44'} value={date} onChange={e=>setDate(e.target.value)}/>
  <span className="ml-auto text-sm text-slate-500">Present {list.length-abs.length} · Absent {abs.length}</span></div>
  {saved&&<div className="mb-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700">Attendance for {cls} on {date} saved.</div>}
  <Table cols={['Roll','Name','Status']}>{list.map(s=>{const a=abs.includes(s.id);return(<tr key={s.id}><td className="px-3 py-2.5">{s.roll}</td><td className="px-3 font-medium">{s.name}</td><td className="px-3"><div className="flex gap-2">
   <button onClick={()=>mark(s.id,false)} className={`flex items-center gap-1 rounded-lg px-3 py-1 text-xs font-medium ${!a?'bg-emerald-600 text-white':'bg-slate-100'}`}><Check size={14}/>Present</button>
   <button onClick={()=>mark(s.id,true)} className={`flex items-center gap-1 rounded-lg px-3 py-1 text-xs font-medium ${a?'bg-red-600 text-white':'bg-slate-100'}`}><X size={14}/>Absent</button></div></td></tr>)})}</Table></Card></>)}

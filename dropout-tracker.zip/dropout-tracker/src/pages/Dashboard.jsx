import {Users,UserCheck,UserX,AlertTriangle} from 'lucide-react';
import {ResponsiveContainer,LineChart,Line,XAxis,YAxis,Tooltip,CartesianGrid,BarChart,Bar} from 'recharts';
import {useData} from '../context/DataContext';import {classStats,weekly,riskOf} from '../data/mock';import {Card,Stat,PageHeader} from '../components/ui';
export default function Dashboard(){const {students,activity}=useData();const abs=students.filter(s=>s.absentToday).length;
 return(<><PageHeader title="Dashboard" subtitle="Overview of today's attendance and dropout risk"/>
 <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
  <Stat icon={Users} label="Total Students" value={students.length}/><Stat icon={UserCheck} tone="green" label="Present Today" value={students.length-abs}/>
  <Stat icon={UserX} tone="red" label="Absent Today" value={abs}/><Stat icon={AlertTriangle} tone="amber" label="At-Risk Students" value={students.filter(s=>riskOf(s)!=='Low').length}/></div>
 <div className="mt-6 grid gap-4 lg:grid-cols-2">
  <Card title="Weekly Attendance %"><div className="h-64"><ResponsiveContainer><LineChart data={weekly}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0"/><XAxis dataKey="d"/><YAxis domain={[70,100]}/><Tooltip/><Line dataKey="v" stroke="#2563eb" strokeWidth={3}/></LineChart></ResponsiveContainer></div></Card>
  <Card title="Class-wise Attendance %"><div className="h-64"><ResponsiveContainer><BarChart data={classStats(students)}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0"/><XAxis dataKey="cls"/><YAxis domain={[60,100]}/><Tooltip/><Bar dataKey="attendance" fill="#3b82f6" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></Card></div>
 <Card title="Recent Activity" className="mt-6"><ul className="divide-y divide-slate-100">{activity.map((a,i)=><li key={i} className="flex justify-between py-2.5 text-sm"><span>{a.text}</span><span className="text-slate-400">{a.time}</span></li>)}</ul></Card></>)}

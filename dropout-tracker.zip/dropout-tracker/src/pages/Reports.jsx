import {useState} from 'react';import {Printer,Download} from 'lucide-react';
import {useData} from '../context/DataContext';import {classStats,monthly,pct,riskOf} from '../data/mock';import {Card,PageHeader,Btn,Table,csv} from '../components/ui';
const TABS=['Daily','Monthly','Student-wise','Class-wise'];
export default function Reports(){const {students}=useData();const [tab,setTab]=useState('Daily');
 const R={Daily:{cols:['ID','Name','Class','Today'],rows:students.map(s=>[s.id,s.name,s.cls,s.absentToday?'Absent':'Present'])},
  Monthly:{cols:['Month','Avg attendance %'],rows:monthly.map(m=>[m.m,m.v])},
  'Student-wise':{cols:['ID','Name','Class','Absent days','Attendance %','Risk'],rows:students.map(s=>[s.id,s.name,s.cls,s.absent,pct(s),riskOf(s)])},
  'Class-wise':{cols:['Class','Students','Attendance %','Absent today','At risk'],rows:classStats(students).map(c=>[c.cls,c.students,c.attendance,c.absent,c.atRisk])}}[tab];
 return(<><PageHeader title="Reports" subtitle="Generate, print and export attendance reports"><Btn variant="ghost" onClick={()=>window.print()}><Printer size={16}/>Print</Btn><Btn onClick={()=>csv(tab.toLowerCase()+'-report',R.cols,R.rows)}><Download size={16}/>Export CSV</Btn></PageHeader>
 <div className="mb-4 flex flex-wrap gap-2 print:hidden">{TABS.map(t=><Btn key={t} variant={t===tab?'primary':'ghost'} onClick={()=>setTab(t)}>{t}</Btn>)}</div>
 <Card title={`${tab} Report · ${new Date().toLocaleDateString()}`}><Table cols={R.cols}>{R.rows.map((r,i)=><tr key={i}>{r.map((v,j)=><td key={j} className="px-3 py-2">{v}</td>)}</tr>)}</Table></Card></>)}

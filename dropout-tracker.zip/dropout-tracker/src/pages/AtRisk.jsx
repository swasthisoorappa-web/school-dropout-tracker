import {useState} from 'react';import {useNavigate} from 'react-router-dom';import {PhoneCall} from 'lucide-react';
import {useData} from '../context/DataContext';import {riskOf,reasonsOf,pct} from '../data/mock';import {Card,PageHeader,Badge,Btn,inp} from '../components/ui';
export default function AtRisk(){const {students}=useData();const go=useNavigate();const [lvl,setLvl]=useState('');
 const list=students.filter(s=>riskOf(s)!=='Low'&&(!lvl||riskOf(s)===lvl)).sort((a,b)=>pct(a)-pct(b));
 return(<><PageHeader title="At-Risk Students" subtitle={`${list.length} students flagged for frequent absences`}><select className={inp+' !w-40'} value={lvl} onChange={e=>setLvl(e.target.value)}><option value="">All risk levels</option><option>High</option><option>Medium</option></select></PageHeader>
 <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{list.map(s=><Card key={s.id}><div className="-m-1 space-y-3"><div className="flex items-start justify-between"><div><p className="font-semibold text-slate-800">{s.name}</p><p className="text-xs text-slate-500">{s.id} · Class {s.cls}</p></div><Badge>{riskOf(s)}</Badge></div>
  <div><div className="mb-1 flex justify-between text-xs"><span>Attendance</span><b>{pct(s)}%</b></div><div className="h-2 rounded-full bg-slate-100"><div className={`h-2 rounded-full ${pct(s)<75?'bg-red-500':'bg-amber-500'}`} style={{width:pct(s)+'%'}}/></div></div>
  <ul className="list-disc pl-5 text-sm text-slate-600">{reasonsOf(s).map(r=><li key={r}>{r}</li>)}</ul>
  <Btn variant="ghost" className="w-full" onClick={()=>go('/follow-ups?student='+s.id)}><PhoneCall size={15}/>Create Follow-up</Btn></div></Card>)}</div></>)}

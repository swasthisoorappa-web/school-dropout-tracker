import {createContext,useContext,useState} from 'react';
import {students as S,followups as F,activity as A} from '../data/mock';
// Single data layer: swap these local setters for API calls (fetch/axios) during backend integration.
const Ctx=createContext();export const useData=()=>useContext(Ctx);
export function DataProvider({children}){
 const [students,setStudents]=useState(S),[followups,setFollowups]=useState(F),[activity,setActivity]=useState(A);
 const log=text=>setActivity(a=>[{text,time:'Just now'},...a].slice(0,8));
 const addStudent=s=>{setStudents(p=>[{...s,id:'S'+(1001+p.length),absent:0,total:60,streak:0,absentToday:false},...p]);log(`New student ${s.name} added`)};
 const saveAttendance=(cls,absentIds)=>{setStudents(p=>p.map(s=>s.cls===cls?{...s,absentToday:absentIds.includes(s.id)}:s));log(`Attendance saved for class ${cls}`)};
 const addFollowup=f=>{setFollowups(p=>[{...f,id:'F'+(p.length+1)},...p]);log('New follow-up scheduled')};
 const updateFollowup=(id,patch)=>setFollowups(p=>p.map(f=>f.id===id?{...f,...patch}:f));
 return <Ctx.Provider value={{students,followups,activity,addStudent,saveAttendance,addFollowup,updateFollowup}}>{children}</Ctx.Provider>}
